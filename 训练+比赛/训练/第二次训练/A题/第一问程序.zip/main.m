clear,clc;
[endpoints, bifurcations] = get_code(1);
fid = fopen('result.txt','wb');
for i = 1:size(endpoints,1)
    fprintf(fid, '%.3f %.3f %.3f %d %d\n', endpoints(i,7), endpoints(i,5), endpoints(i,6), 1, endpoints(i,3));
end
for i = 1:size(bifurcations,1)
    fprintf(fid, '%.3f %.3f %.3f %d %d\n', bifurcations(i,7), bifurcations(i,5), bifurcations(i,6), 2, bifurcations(i,3));
end
fclose(fid);