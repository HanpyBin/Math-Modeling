function [endpoint_x, endpoint_y, bifurcation_x, bifurcation_y]=feat(A, msk,ord)
msk1 = msk;
[row,vol]=size(A);
endpoint=zeros(row,vol);
bifurcation=zeros(row,vol);
for i=2:row-1
    for j=2:vol-1
        if A(i,j)==1
            continue;
        end
        D=[A(i-1,j-1) A(i-1,j) A(i-1,j+1);A(i,j-1) A(i,j) A(i,j+1);A(i+1,j-1) A(i+1,j) A(i+1,j+1)];
        onenum=nnz(D);
        zeronum=8-onenum;%�����ڽӵ�ڵ�ĸ���
        if zeronum==1%�ж��Ƿ�˵�
            endpoint(i,j)=1;
        end
        if zeronum==3%�ж��Ƿ�ֲ��
            if A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==0 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==0 && A(i,j+1)==1 && A(i+1,j-1)==1 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==0 && A(i,j+1)==1 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==0 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==0 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==0 && A(i,j+1)==1 && A(i+1,j-1)==1 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==1 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==0 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==1 && A(i-1,j+1)==0 && A(i,j-1)==1 && A(i,j+1)==1 && A(i+1,j-1)==0 && A(i+1,j)==1 && A(i+1,j+1)==0
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==0 && A(i,j+1)==0 && A(i+1,j-1)==1 && A(i+1,j)==1 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==1 && A(i-1,j+1)==1 && A(i,j-1)==0 && A(i,j+1)==0 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==0 && A(i,j+1)==0 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            elseif A(i-1,j-1)==1 && A(i-1,j)==0 && A(i-1,j+1)==1 && A(i,j-1)==1 && A(i,j+1)==0 && A(i+1,j-1)==1 && A(i+1,j)==0 && A(i+1,j+1)==1
                bifurcation(i,j)=1;
            else
                continue;
            end
        end
    end
end

%ȥ����ԵЧӦ��ȥ������ͼ���Ե25���ڵ�������
ra = 25;
drop_x = [];
drop_y = [];
for i = 1:row
    for j = 1:vol
        if msk(i,j)==1
            drop_x(end+1)=i;
            drop_y(end+1)=j;
            msk1(i,j)=0;
            for k = j+1:j+ra-1
                if msk(i,k)==1
                    drop_x(end+1)=i;
                    drop_y(end+1)=k;
                    msk1(i,k)=0;
                else
                    break;
                end
            end
            break;
        end
    end
end

for i = 1:row
    for j = vol:-1:1
        if msk(i,j)==1
            drop_x(end+1)=i;
            drop_y(end+1)=j;
            msk1(i,j)=0;
            for k = j-1:-1:j+1-ra
                if msk(i,k)==1
                    drop_x(end+1)=i;
                    drop_y(end+1)=k;
                    msk1(i,k)=0;
                else
                    break;
                end
            end
            break;
        end
    end
end

for i = 1:vol
    for j = 1:row
        if msk(j,i)==1
            drop_x(end+1)=j;
            drop_y(end+1)=i;
            msk1(j,i)=0;
            for k = j+1:j+ra-1
                if msk(k,i)==1
                    drop_x(end+1)=k;
                    drop_y(end+1)=i;
                    msk1(k,i)=0;
                else
                    break;
                end
            end
            break;
        end
    end
end

for i = 1:vol
    for j = row:-1:1
        if msk(j,i)==1
            drop_x(end+1)=j;
            drop_y(end+1)=i;
            msk1(j,i)=0;
            for k = j-1:-1:j+1-ra
                if msk(k,i)==1
                    drop_x(end+1)=k;
                    drop_y(end+1)=i;
                    msk1(k,i)=0;
                else
                    break;
                end
            end
            break;
        end
    end
end

drop_ord = sub2ind(size(endpoint),drop_x,drop_y);
endpoint(drop_ord) = 0;
bifurcation(drop_ord)=0;


%ȥ���ϵ㣬ȥ�����С��6�������˵�
for i=1:row
    for j=1:vol
        if msk1(i,j)==1
            if endpoint(i,j)==1
                flag=0;
                for k=i-5:i+5
                    for l=j-5:j+5
                        if k==i && l==j
                            continue;
                        end
                        if endpoint(k,l)==1
                            endpoint(k,l)=0;
                            flag=1;
                        end
                    end
                end
                if flag==1
                    endpoint(i,j)=0;
                end
            end
        end
    end
end

for i=1:row%ȥ��αС�š�С����ë�̣�ͨ�����ֲ����Ϊ��ʼ�����������ߣ��������ֲ����߷ֲ��Ͷ˵�ľ���С��12����ɾ��
    for j=1:vol
        if msk1(i,j) == 1
            if bifurcation(i,j)==1
                flag=0;
                m=1;
                abc=zeros(3,2);
                for k=i-1:i+1%��¼��ʼ�ֲ����������ڵ�λ��
                    for l=j-1:j+1
                        if k==i && l==j
                            continue;
                        end
                        if A(k,l)==0;
                            abc(m,1)=k;
                            abc(m,2)=l;
                            m=m+1;
                        end
                    end
                end
                for n=1:3%�ֱ���������ڵ���м���
                    temr=abc(n,1);
                    temv=abc(n,2);
                    D=[A(temr-1,temv-1) A(temr-1,temv) A(temr-1,temv+1);A(temr,temv-1) A(temr,temv) A(temr,temv+1);A(temr+1,temv-1) A(temr+1,temv) A(temr+1,temv+1)];
                    onenum=nnz(D);
                    zeronum=8-onenum;
                    if zeronum>3
                        bifurcation(temr,temv)=0;
                        flag=1;
                        continue;
                    end
                    ind=1;
                    def=zeros(2,2);
                    for o=1:2
                        if o==n
                            ind=ind+1;
                        end
                        def(o,1)=abc(ind,1);
                        def(o,2)=abc(ind,2);
                        ind=ind+1;
                    end
                    if zeronum==3 && ((def(1,1)<temr-1 || def(1,1)>temr+1 || def(1,2)<temv-1 || def(1,2)>temv+1) && (def(2,1)<temr-1 || def(2,1)>temr+1 || def(2,2)<temv-1 || def(2,2)>temv+1))
                        bifurcation(temr,temv)=0;
                        flag=1;
                        continue;
                    end
                    if zeronum==1
                        endpoint(temr,temv)=0;
                        flag=1;
                        continue;
                    end
                    ghi=zeros(2,2);
                    if zeronum==3
                        if (abs(def(1,1)-temr)<=1) && (abs(def(1,2)-temv)<=1)
                            ind=1;
                        elseif (abs(def(2,1)-temr)<=1) && (abs(def(2,2)-temv)<=1)
                            ind=2;
                        end
                        r=0;
                        for p=temr-1:temr+1
                            for q=temv-1:temv+1
                                if p==temr && q==temv
                                    continue;
                                end
                                if A(p,q)==0
                                    if ~((p==def(ind,1) && q==def(ind,2)) || (p==i && q==j))
                                        ghi(1,1)=p;
                                        ghi(1,2)=q;
                                        r=1;
                                        break;
                                    end
                                end
                            end
                            if r==1
                                break;
                            end
                        end
                    end
                    if zeronum==2
                        r=0;
                        for p=temr-1:temr+1
                            for q=temv-1:temv+1
                                if p==temr && q==temv
                                    continue;
                                end
                                if A(p,q)==0
                                    if ~(p==i && q==j)
                                        ghi(1,1)=p;
                                        ghi(1,2)=q;
                                        r=1;
                                        break;
                                    end
                                end
                            end
                            if r==1
                                break;
                            end
                        end
                        if (ghi(1,1)==def(1,1) && ghi(1,2)==def(1,2)) || (ghi(1,1)==def(2,1) && ghi(1,2)==def(2,2))
                            continue;
                        end
                    end
                    ghi(2,1)=temr;
                    ghi(2,2)=temv;
                    for s=1:9
                        t=ghi(1,1);
                        v=ghi(1,2);
                        w=ghi(2,1);
                        x=ghi(2,2);
                        if endpoint(t,v)==1
                            endpoint(t,v)=0;
                            flag=1;
                            break;
                        end
                        if bifurcation(t,v)==1
                            bifurcation(t,v)=0;
                            flag=1;
                            break;
                        end
                        r=0;
                        for p=t-1:t+1
                            for q=v-1:v+1
                                if p==t && q==v
                                    continue;
                                end
                                if A(p,q)==0
                                    if ~(p==w && q==x)
                                        ghi(1,1)=p;
                                        ghi(1,2)=q;
                                        r=1;
                                        break;
                                    end
                                end
                            end
                            if r==1
                                ghi(2,1)=t;
                                ghi(2,2)=v;
                                break;
                            end
                        end
                    end
                end
                if flag==1
                    bifurcation(i,j)=0;
                end
            end
        end
    end
end

% [X,map]=gray2ind(A,256);%��ʾ�˵�ͷֲ�㣬�ֲ���ú�ɫ��ʾ���˵�����ɫ��ʾ
% RGB=ind2rgb(X,map);
% RGB2=RGB;
% for i=2:row-1
%     for j=2:vol-1
%         if RGB(i,j,1)==0 && RGB(i,j,2)==0 && RGB(i,j,3)==0
%             if endpoint(i,j)==1
%                 RGB2(i,j,1)=0;
%                 RGB2(i,j,2)=1;
%                 RGB2(i-1,j,2)=1;
%                 RGB2(i,j-1,2)=1;
%                 RGB2(i,j+1,2)=1;
%                 RGB2(i+1,j,2)=1;
%                 RGB2(i,j,3)=0;
%             end
%             if bifurcation(i,j)==1
%                 RGB2(i,j,1)=1;
%                 RGB2(i-1,j,1)=1;
%                 RGB2(i,j-1,1)=1;
%                 RGB2(i,j+1,1)=1;
%                 RGB2(i+1,j,1)=1;
%                 RGB2(i,j,2)=0;
%                 RGB2(i,j,3)=0;
%             end
%         end
%     end
% end
% 
% T=RGB2;
[endpoint_x, endpoint_y] = find(endpoint==1);
[bifurcation_x, bifurcation_y] = find(bifurcation==1);
figure,imshow(A);
hold on;
plot(endpoint_y, endpoint_x, 'go');
plot(bifurcation_y, bifurcation_x, 'ro');
hold off;
saveas(gcf, [num2str(ord),'������'], 'png')